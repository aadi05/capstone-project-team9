export class User {
    firstName: string;
    lastName: string;
    username:string;
    password: string;
    phone: number;
    address:string;
    pancard:string;
    email: string;
    }
     